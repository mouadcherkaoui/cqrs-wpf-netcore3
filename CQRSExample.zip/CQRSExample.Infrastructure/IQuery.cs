﻿namespace CQRSExample.Infrastructure
{
    public interface IQuery<TResult>
    {
        // IQuery<TResult> Query { get; }
    }
}